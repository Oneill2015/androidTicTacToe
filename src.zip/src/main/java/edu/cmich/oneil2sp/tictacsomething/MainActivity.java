package edu.cmich.oneil2sp.tictacsomething;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    public static final String PREFS_NAME = "MyPrefsFile";
    TextView tv;
    Button spot1, spot2, spot3, spot4, spot5, spot6, spot7, spot8, spot9;
    SharedPreferences sharedPreferences;
    Context context;
    int turnOrder = 0;
    int[] myarray = {0,0,0,0,0,0,0,0,0,0};
    int h,v,d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.textView);
        context = this.getApplicationContext();
        sharedPreferences = context.getSharedPreferences("TicTacSomething", Context.MODE_PRIVATE);
        spot1 = (Button)findViewById(R.id.button);
        spot2 = (Button)findViewById(R.id.button2);
        spot3 = (Button)findViewById(R.id.button3);
        spot4 = (Button)findViewById(R.id.button4);
        spot5 = (Button)findViewById(R.id.button5);
        spot6 = (Button)findViewById(R.id.button6);
        spot7 = (Button)findViewById(R.id.button7);
        spot8 = (Button)findViewById(R.id.button8);
        spot9 = (Button)findViewById(R.id.button9);




    }
    public void makeAMove(View R) {

                if (myarray[0]==0 ) {
                    String y = getTurn();
                    spot1.setText(y);
                    updateTextView();
                    if (y == "X") {
                        myarray[0] = 1;
                        myarray[9]++;
                    } else {
                        myarray[0] = 2;
                        myarray[9]++;

                    }
                    whoWins();
                }



    }
    public void makeAMove2(View R) {
            if (myarray[1]==0 ) {
                String y = getTurn();
                spot2.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[1] = 1;
                    myarray[9]++;
                } else {
                    myarray[1] = 2;
                    myarray[9]++;
                }
                whoWins();
            }

    }
    public void makeAMove3(View R) {
            if (myarray[2]==0 ) {
                String y = getTurn();
                spot3.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[2] = 1;
                    myarray[9]++;
                } else {
                    myarray[2] = 2;
                    myarray[9]++;
                }
                whoWins();
            }


    }
    public void makeAMove4(View R) {
        if (myarray[3]==0 ) {
                String y = getTurn();
                spot4.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[3] = 1;
                    myarray[9]++;
                } else {
                    myarray[3] = 2;
                    myarray[9]++;
                }
                whoWins();
            }

    }
    public void makeAMove5(View R) {
            if (myarray[4]==0 ) {
                String y = getTurn();
                spot5.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[4] = 1;
                    myarray[9]++;
                } else {
                    myarray[4] = 2;
                    myarray[9]++;
                }
                whoWins();
            }

    }
    public void makeAMove6(View R) {
            if (myarray[5]==0 ) {
                String y = getTurn();
                spot6.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[5] = 1;
                    myarray[9]++;
                } else {
                    myarray[5] = 2;
                    myarray[9]++;
                }
                whoWins();
            }

    }
    public void makeAMove7(View R) {
            if (myarray[6]==0 ) {
                String y = getTurn();
                spot7.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[6] = 1;
                    myarray[9]++;
                } else {
                    myarray[6] = 2;
                    myarray[9]++;
                }
                whoWins();

            }

    }
    public void makeAMove8(View R) {
            if (myarray[7]==0 ) {
                String y = getTurn();
                spot8.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[7] = 1;
                    myarray[9]++;
                } else {
                    myarray[7] = 2;
                    myarray[9]++;
                }
                whoWins();

            }

    }
    public void makeAMove9(View R) {
            if (myarray[8]==0 ) {
                String y = getTurn();
                spot9.setText(y);
                updateTextView();
                if (y == "X") {
                    myarray[8] = 1;
                    myarray[9]++;
                } else {
                    myarray[8] = 2;
                    myarray[9]++;
                }
                whoWins();

            }

    }

    public void onResume() {
        super.onResume();
        SharedPreferences myPrefs1 = getApplicationContext().getSharedPreferences("MyPrefsFile", 0);
        myarray[0] = myPrefs1.getInt("myValue", 0);
        myarray[1] = myPrefs1.getInt("myValue2", 0);
        myarray[2] = myPrefs1.getInt("myValue3", 0);
        myarray[3] = myPrefs1.getInt("myValue4", 0);
        myarray[4] = myPrefs1.getInt("myValue5", 0);
        myarray[5] = myPrefs1.getInt("myValue6", 0);
        myarray[6] = myPrefs1.getInt("myValue7", 0);
        myarray[7] = myPrefs1.getInt("myValue8", 0);
        myarray[8] = myPrefs1.getInt("myValue9", 0);
        myarray[9] = myPrefs1.getInt("move", 0);

        if (myarray[0] ==1) {
            spot1.setText("X");
        } else if(myarray[0] == 2) {
            spot1.setText("O");
        }
        if (myarray[1] ==1) {
            spot2.setText("X");
        } else if(myarray[1] == 2) {
            spot2.setText("O");
        }
        if (myarray[2] ==1) {
            spot3.setText("X");
        } else if(myarray[2] == 2) {
            spot3.setText("O");
        }
        if (myarray[3] ==1) {
            spot4.setText("X");
        } else if(myarray[3] == 2) {
            spot4.setText("O");
        }
        if (myarray[4] ==1) {
            spot5.setText("X");
        } else if(myarray[4] == 2) {
            spot5.setText("O");
        }
        if (myarray[5] ==1) {
            spot6.setText("X");
        } else if(myarray[5] == 2) {
            spot6.setText("O");
        }
        if (myarray[6] ==1) {
            spot7.setText("X");
        } else if(myarray[6] == 2) {
            spot7.setText("O");
        }
        if (myarray[7] ==1) {
            spot8.setText("X");
        } else if(myarray[7] == 2) {
            spot8.setText("O");
        }
        if (myarray[8] ==1) {
            spot9.setText("X");
        } else if(myarray[8] == 2) {
            spot9.setText("O");
        }
        if (myarray[9] %2 == 0) {
            turnOrder=myarray[9];
            turnOrder--;
            getTurn();
            updateTextView();

        } else if(myarray[9] % 2 == 1) {
            turnOrder=myarray[9];
            turnOrder--;
            getTurn();
            updateTextView();

        }
    }

    public void onPause() {
        super.onPause();
        SharedPreferences prefs = getApplicationContext().getSharedPreferences("MyPrefsFile", 0);
        SharedPreferences.Editor prefsEditor = prefs.edit();
        prefsEditor.putInt("myValue", myarray[0]);
        prefsEditor.putInt("myValue2", myarray[1]);
        prefsEditor.putInt("myValue3", myarray[2]);
        prefsEditor.putInt("myValue4", myarray[3]);
        prefsEditor.putInt("myValue5", myarray[4]);
        prefsEditor.putInt("myValue6", myarray[5]);
        prefsEditor.putInt("myValue7", myarray[6]);
        prefsEditor.putInt("myValue8", myarray[7]);
        prefsEditor.putInt("myValue9", myarray[8]);
        prefsEditor.putInt("move", myarray[9]);
        prefsEditor.commit();
        //sharedPreferences.edit().putInt("MyPrefsFile", myarray[0]);
        //sharedPreferences.edit().commit();
        //putString()
    }

    public String getTurn() {
        turnOrder++;
        String x;
        if (turnOrder % 2 == 1) {
            x = "X";
        } else {
            x = "O";
        }

        return x;
    }
    public void whoWins() {
        TextView textView = (TextView) findViewById(R.id.textView);
        int hor = horizontalWin();
        int ver = verticalWin();
        int dia = diagonalWin();
        if (hor != 0) {
            if (hor == 1) {
                textView.setText("Player 1 wins!");
                fillAll();
            }else if (hor == 2) {
                textView.setText("Player 2 wins!");
                fillAll();
            }

        } else if(ver != 0) {
            if (ver == 1) {
                textView.setText("Player 1 wins!");
                fillAll();
            }else if (ver == 2) {
                textView.setText("Player 2 wins!");
                fillAll();
            }

        } else if (dia != 0) {
            if (dia == 1) {
                textView.setText("Player 1 wins!");
                fillAll();
            }else if (dia == 2) {
                textView.setText("Player 2 wins!");
                fillAll();
            }

        } else {
            if(myarray[0] >0) {
                if (myarray[1] > 0) {
                    if (myarray[2] > 0) {
                        if (myarray[3] > 0) {
                            if(myarray[4] > 0) {
                                if(myarray[5] > 0) {
                                    if (myarray[6] > 0) {
                                        if (myarray[7] > 0) {
                                            if (myarray[8] > 0) {
                                                textView.setText("It's a tie!");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }


        }


    }
    public void updateTextView() {
        TextView textView = (TextView) findViewById(R.id.textView);
        if (turnOrder % 2 ==1) {
            textView.setText("Player 2's turn");
        } else {
            textView.setText("Player 1's turn");
        }


    }
    public void newGame(View R) {
        clearAll();

    }
    public void clearAll() {
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText("Player 1's turn");
        spot1.setText("");
        spot2.setText("");
        spot3.setText("");
        spot4.setText("");
        spot5.setText("");
        spot6.setText("");
        spot7.setText("");
        spot8.setText("");
        spot9.setText("");
        turnOrder = 0;
        myarray = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        h = 0;
        d = 0;
        v = 0;
    }
    public int horizontalWin() {
        h=0;

        if (myarray[0] == myarray[1] && myarray[1] ==myarray[2]) {
            if (myarray[0] > 0) {
                h = myarray[0];
            }
        }
        if (myarray[3] == myarray[4] && myarray[4] ==myarray[5]) {
            if (myarray[3] > 0) {
                h = myarray[3];
            }
        }
        if (myarray[6] == myarray[7] && myarray[7] ==myarray[8]) {
            if (myarray[6] > 0) {
                h = myarray[6];
            }
        }

        return h;
    }
    public int verticalWin() {
        v = 0;
        if (myarray[0] == myarray[3] && myarray[3] ==myarray[6]) {
            if(myarray[0] > 0) {
                v = myarray[0];
            }
        }
        if (myarray[1] == myarray[4] && myarray[4] ==myarray[7]) {
            if (myarray[1] > 0) {
                v = myarray[1];
            }
        }
        if (myarray[2] == myarray[5] && myarray[5] ==myarray[8]) {
            if (myarray[2] > 0) {
                v = myarray[2];
            }
        }

        return v;

    }
    public int diagonalWin() {
        if (myarray[0] == myarray[4] && myarray[4] ==myarray[8]) {
            if (myarray[0] > 0) {
                d = myarray[0];
            }
        } else if (myarray[2] == myarray[4] && myarray[4] ==myarray[6]) {
            if (myarray[2] > 0) {
                d = myarray[2];
            }

        } else {
            d = 0;
        }

        return d;
    }
    public void fillAll() {
        for (int x = 0; x < myarray.length; x++) {
            if (myarray[x] == 0) {
                myarray[x] = 5;
            }
        }
    }


}

